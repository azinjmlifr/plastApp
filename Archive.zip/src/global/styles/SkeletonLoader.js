import styled from "@emotion/styled";

export const SkeletonWrapper = styled.div``;
