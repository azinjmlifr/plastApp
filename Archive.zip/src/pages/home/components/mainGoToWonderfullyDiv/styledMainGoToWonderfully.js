import styled from "@emotion/styled";

export const FlexWonderfullyContainer = styled.div`
  width: 90%;
  margin: 0 auto;
  display: flex;
  gap: 20px;
`;
