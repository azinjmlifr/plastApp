import React from "react";

const LoginComponent = () => {
  return <div>LoginComponent</div>;
};

export default LoginComponent;
