export const MAIN_SLIDER_IMGS = { url: "config/slider", method: "get" };
export const MAIN_CATEGORIES = { url: "category/list", method: "get" };
export const MAIN_SUGGESTED_PRODUCTS = { url: "config", method: "get" };
export const MAIN_BANNERS = {
  url: "advertise/notice_banner",
  method: "get",
};
// MAIN_POPULAR_PRODUCTS
