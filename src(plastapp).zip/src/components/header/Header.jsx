import React from "react";

import { HeaderDiv } from "./styledheader/styled";

const Header = () => {
  return <HeaderDiv />;
};

export default Header;
