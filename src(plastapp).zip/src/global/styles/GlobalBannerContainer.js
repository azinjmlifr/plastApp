import styled from "@emotion/styled";

export const GlobalBannerContainer = styled.div`
  width: 75%;
  margin: 0 auto;
`;
