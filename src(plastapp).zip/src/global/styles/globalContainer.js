import styled from "@emotion/styled";

export const GlobalContainer = styled.div`
  width: 90%;
  margin: 0 auto;
`;
