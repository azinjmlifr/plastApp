export const navLan = {
  login_button: "ثبت نام | ورود",
};

export const HomeLan = {
  search_input_button: "تهران",
  search_button: "ادامه",

  mainCategory_Title: "گروه محصول خود را انتخاب کنید",

  mainSuggested_title: "پیشنهاد ویژه",

  mainTopShops_title: "جدیدترین فروشگاه ها",

  mainPopularShops_title: "محبوب ترین فروشگاه ها",

  mainPopularProducts_title: "محصولات پرفروش",

  mainAllProducts_title: "محصولات",

  mainWonderfullyDiscountProducts_title: "بیش از ۳ ",

  mainWonderfullyDiscountProducts_title_continue: "کالا",

  footerFirstRowFirstColumn_title: "مراحل ثبت سفارش",
  footerFirstRowSecondColumn_title: "شرایط خرید اعتباری",
  footerFirstRowThirdColumn_title: "پشتیبانی",
  footerFirstRowFourthColumn_title: "قوانین و مقررات",
  footerFirstRowFifthColumn_title: "مراحل ثبت فروشگاه",

  footer24Support: "پشتیبانی ۲۴ ساعته",
  footerPhoneNumberSupport: " 021-91030809",

  footerLastTitle:
    "کلیه حقوق مادی و معنوی سایت و اپلیکیشن (پلاست اپ) متعلق به شرکت کیان تجارت تام ایرانیان می باشد.",
};
