import styled from "@emotion/styled";

export const FlexBannerImage = styled.div`
  .img {
    aspect-ratio: 16 / 8;
  }
`;
