import styled from "@emotion/styled";

export const FlexBannerDiv = styled.div`
  display: flex;
  gap: 30px;
`;
