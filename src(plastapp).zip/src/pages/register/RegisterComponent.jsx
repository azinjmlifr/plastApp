import React from "react";

const RegisterComponent = () => {
  return <div>RegisterComponent</div>;
};

export default RegisterComponent;
